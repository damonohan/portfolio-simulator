===== PORTFOLIO SIMULATOR =====

GETTING STARTED:

1. DOUBLE-CLICK the "install_portfolio_simulator.command" file.

   * If you see a security warning:
     - Right-click (or Control-click) the file 
     - Select "Open" from the menu
     - Click "Open" in the security dialog that appears

2. A Terminal window will open and guide you through the rest of the process.

3. If you don't have Python installed, the installer will direct you to download it.
   After installing Python, double-click the command file again.

That's it! No technical knowledge required.

===== ENJOY YOUR PORTFOLIO SIMULATION! ===== 