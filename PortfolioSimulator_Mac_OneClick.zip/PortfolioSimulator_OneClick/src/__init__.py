# Portfolio Simulator
# 
# A tool for simulating and comparing different investment portfolio strategies,
# including traditional stock/bond allocations and structured notes. 